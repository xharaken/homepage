#!/usr/bin/perl
use Cwd;
die "usage: $0 processors\n" unless @ARGV >= 1;

my $pnum = $ARGV[0];
my $result = $ARGV[1] || "run_$pnum";
my $exe_suffix = $ARGV[2] || "";

my $nodes = 0;
my $np = 0;
my $tnum = 0;
if ($pnum == 1) {
  $nodes = 1;
  $np = 1;
  $tnum = 1;
} elsif ($pnum == 2) {
  $nodes = 1;
  $np = 1;
  $tnum = 2;
} elsif ($pnum == 4) {
  $nodes = 1;
  $np = 1;
  $tnum = 4;
} elsif ($pnum == 8) {
  $nodes = 2;
  $np = 4;
  $tnum = 2;
} elsif ($pnum == 16) {
  $nodes = 4;
  $np = 4;
  $tnum = 4;
} elsif ($pnum == 32) {
  $nodes = 8;
  $np = 16;
  $tnum = 2;
} elsif ($pnum == 64) {
  $nodes = 16;
  $np = 16;
  $tnum = 4;
} elsif ($pnum == 128) {
  $nodes = 32;
  $np = 64;
  $tnum = 2;
} else {
  die "# of processors is not a power of 2.\n";
}

my $sh_file = "run_tmp_${nodes}_${np}_${pnum}.sh";
my $exe_file = getcwd() . "/matmul_$np$exe_suffix";
open FH, "> $sh_file" or die "Cannot write a file.\n";
print FH "#PBS -l nodes=$nodes\n";
print FH "EXE=$exe_file\n";
print FH "RUN=/usr/lib64/openmpi/bin/mpirun\n";
print FH "\$RUN -np $np -hostfile \$PBS_NODEFILE \$EXE $tnum\n";
close FH;

system "qsub -o $result.out -e $result.err $sh_file";

unlink $sh_file or die;
