my @sizes = (1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16, 17, 32, 64, 128, 256, 512, 1024, 2048, 4096, 100, 999, 1000, 1001, 2000, 3000, 4000, 5000);

open FH, "> tests_compile.sh" or die;
print FH "export PATH=/usr/lib64/openmpi/bin:/opt/xmp-R1272/bin:\$PATH\n";
print FH "gcc -o matmul_util.o -Wall -O3 -std=c99 -c matmul_util.c\n";
print FH "gcc -o matmul_core.o -Wall -O3 -std=c99 -c matmul_core.c\n";
for my $size (@sizes) {
  for my $nodes (1, 4, 16, 64) {
    print FH "xmpcc -o matmul_main_1.o -Wall -O3 -DSQRT_PNUM_OVERWRITE=1 -DSIZE_OVERWRITE=$size -std=c99 -c matmul_main.c\n";
    print FH "xmpcc -o matmul_main_4.o -Wall -O3 -DSQRT_PNUM_OVERWRITE=2 -DSIZE_OVERWRITE=$size -std=c99 -c matmul_main.c\n";
    print FH "xmpcc -o matmul_main_16.o -Wall -O3 -DSQRT_PNUM_OVERWRITE=4 -DSIZE_OVERWRITE=$size -std=c99 -c matmul_main.c\n";
    print FH "xmpcc -o matmul_main_64.o -Wall -O3 -DSQRT_PNUM_OVERWRITE=8 -DSIZE_OVERWRITE=$size -std=c99 -c matmul_main.c\n";
    print FH "xmpcc -o matmul_1_$size matmul_main_1.o matmul_core.o matmul_util.o -lm -lpthread\n";
    print FH "xmpcc -o matmul_4_$size matmul_main_4.o matmul_core.o matmul_util.o -lm -lpthread\n";
    print FH "xmpcc -o matmul_16_$size matmul_main_16.o matmul_core.o matmul_util.o -lm -lpthread\n";
    print FH "xmpcc -o matmul_64_$size matmul_main_64.o matmul_core.o matmul_util.o -lm -lpthread\n";
  }
}
close FH;

open FH, "> tests_qsub.sh" or die;
print FH "export PATH=/usr/lib64/openmpi/bin:/opt/xmp-R1272/bin:\$PATH\n";
for my $size (@sizes) {
  for my $np (1, 2, 4, 8, 16, 32, 64, 128) {
    next if ($np <= 4 && $size > 512);
    print FH "./exec_matmul.pl $np test_run_${np}_${size} _$size\n";
  }
  if ($size > 512) {
    print FH "sleep 120\n";
  } else {
    print FH "sleep 20\n";
  }
}
close FH;
