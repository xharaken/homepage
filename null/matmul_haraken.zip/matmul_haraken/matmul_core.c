#include "matmul_core.h"
#include "matmul_util.h"
// xmpcc fails when compilng a file that includes <pthread.h>.
// You have to build this file with gcc.
#include <pthread.h>

#define TNUM_MAX 4
#define PHASE_MAX 16

enum phase_state {
  STATE_EMPTY,
  STATE_SCHEDULED,
  STATE_DONE
};

typedef struct targ_t {
  pthread_t handle;
  pthread_mutex_t mutex;
  pthread_cond_t cond;
  int tid;
  int cpuid;
  int tnum;
  double* a;
  double* b;
  double* c;
  int n;
  int states[PHASE_MAX + 1];
} targ_t;

struct threads_struct {
  int tnum;
  targ_t targs[TNUM_MAX];
};

void matmul_core_test(double* restrict a, double* restrict b, double* restrict c, const int n, const int tid, const int tnum)
{
    int i, j, k;
    int begin_i = n / tnum * tid;
    int end_i = tid == tnum - 1 ? n : n / tnum * (tid + 1);
    for (i = begin_i; i < end_i; i++) {
      for (j = 0; j < n; j++) {
        double sum = 0;
        for (k = 0; k < n; k++) {
          sum += a[i * n + k] * b[k * n + j];
        }
        c[i * n + j] += sum;
      }
    }
}

void matmul_core_aligned(double* restrict a, double* restrict b, double* restrict c, const int n, const int tid, const int tnum)
{
  // Maunally optimized.
  const int prefetch = 64;
  const int block = 32;

  int i, j, k;
  int ii, kk;
  int begin_ii = n / tnum * tid;
  int end_ii = tid == tnum - 1 ? n : n / tnum * (tid + 1);
  for (ii = begin_ii; ii < end_ii; ii += block) {
    for (kk = 0; kk < n; kk += block) {
      double* ap = &a[ii * n + kk];
      double* bp_head = &b[kk * n];
      double* cp_head = &c[ii * n];
      int imax = min(ii + block, end_ii);
      for (i = ii; i < imax; i++) {
        double* bp = bp_head;
        int kmax = min(kk + block, n);
        for (k = kk; k < kmax; k++) {
          double* cp = cp_head;
          __asm__("movsd (%0),%%xmm9"::"r"(ap));
          __asm__("movddup %xmm9,%xmm0");
          for (j = 0; j + 8 <= n; j += 8) {
            __asm__("prefetcht0 (%0)"::"r"(bp + prefetch));
            __asm__("prefetcht0 (%0)"::"r"(cp + prefetch));
            __asm__("movapd (%0),%%xmm1"::"r"(bp));
            __asm__("movapd (%0),%%xmm2"::"r"(bp + 2));
            __asm__("movapd (%0),%%xmm3"::"r"(bp + 4));
            __asm__("movapd (%0),%%xmm4"::"r"(bp + 6));
            __asm__("mulpd %xmm0,%xmm1");
            __asm__("mulpd %xmm0,%xmm2");
            __asm__("mulpd %xmm0,%xmm3");
            __asm__("mulpd %xmm0,%xmm4");
            __asm__("movapd (%0),%%xmm5"::"r"(cp));
            __asm__("movapd (%0),%%xmm6"::"r"(cp + 2));
            __asm__("movapd (%0),%%xmm7"::"r"(cp + 4));
            __asm__("movapd (%0),%%xmm8"::"r"(cp + 6));
            __asm__("addpd %xmm1,%xmm5");
            __asm__("addpd %xmm2,%xmm6");
            __asm__("addpd %xmm3,%xmm7");
            __asm__("addpd %xmm4,%xmm8");
            __asm__("movapd %%xmm5,(%0)"::"r"(cp));
            __asm__("movapd %%xmm6,(%0)"::"r"(cp + 2));
            __asm__("movapd %%xmm7,(%0)"::"r"(cp + 4));
            __asm__("movapd %%xmm8,(%0)"::"r"(cp + 6));
            bp += 8;
            cp += 8;
          }
          for (; j < n; j++) {
            (*cp) += (*ap) * (*bp);
            bp++;
            cp++;
          }
          ap++;
        }
        ap += n - kmax + kk;
        cp_head += n;
      }
    }
  }
}

void matmul_core(double* restrict a, double* restrict b, double* restrict c, const int n, const int tid, const int tnum)
{
  //matmul_core_test(a, b, c, n, tid, tnum);
  matmul_core_aligned(a, b, c, n, tid, tnum);
}

void* thread_func(void* ptr)
{
  targ_t* targ = (targ_t*)ptr;
  bind_to_cpu(targ->tid + targ->cpuid);
  while (1) {
    int phase = PHASE_MAX;
    pthread_mutex_lock(&targ->mutex);
    while (1) {
      if (targ->states[phase] == STATE_DONE) {
        break;
      }
      for (phase = 0; phase < PHASE_MAX; phase++) {
        if (targ->states[phase] == STATE_SCHEDULED) {
          break;
        }
      }
      if (phase != PHASE_MAX)
        break;
      pthread_cond_wait(&targ->cond, &targ->mutex);
    }
    pthread_mutex_unlock(&targ->mutex);
    if (phase == PHASE_MAX)
      break;

    int offset = phase * targ->n * targ->n;
    matmul_core(targ->a + offset, targ->b + offset, targ->c, targ->n, targ->tid, targ->tnum);

    pthread_mutex_lock(&targ->mutex);
    targ->states[phase] = STATE_DONE;
    pthread_cond_broadcast(&targ->cond);
    pthread_mutex_unlock(&targ->mutex);
  }
  return NULL;
}

threads_t* thread_create(int tnum, int cpuid, double* a, double* b, double* c, int n)
{
  threads_t* threads = (threads_t*)malloc(sizeof(threads_t));
  threads->tnum = tnum;

  int tid;
  for (tid = 0; tid < threads->tnum; tid++) {
    targ_t* targ = &threads->targs[tid];
    pthread_mutex_init(&targ->mutex, NULL);
    pthread_cond_init(&targ->cond, NULL);
    int phase;
    for (phase = 0; phase <= PHASE_MAX; phase++) {
      targ->states[phase] = STATE_EMPTY;
    }
    targ->tid = tid;
    targ->cpuid = cpuid;
    targ->tnum = tnum;
    targ->a = a;
    targ->b = b;
    targ->c = c;
    targ->n = n;
    pthread_create(&targ->handle, NULL, thread_func, targ);
  }
  return threads;
}

void thread_join(threads_t* threads)
{
  int tid;
  for (tid = 0; tid < threads->tnum; tid++) {
    targ_t* targ = &threads->targs[tid];
    pthread_mutex_lock(&targ->mutex);
    targ->states[PHASE_MAX] = STATE_DONE;
    pthread_cond_broadcast(&targ->cond);
    pthread_mutex_unlock(&targ->mutex);
    pthread_join(targ->handle, NULL);
  }
  free(threads);
}

void thread_start(threads_t* threads, int phase)
{
  int tid;
  for (tid = 0; tid < threads->tnum; tid++) {
    targ_t* targ = &threads->targs[tid];
    pthread_mutex_lock(&targ->mutex);
    targ->states[phase] = STATE_SCHEDULED;
    pthread_cond_broadcast(&targ->cond);
    pthread_mutex_unlock(&targ->mutex);
  }
}

void thread_wait(threads_t* threads, int phase)
{
  int tid;
  for (tid = 0; tid < threads->tnum; tid++) {
    targ_t* targ = &threads->targs[tid];
    pthread_mutex_lock(&targ->mutex);
    while (targ->states[phase] != STATE_DONE) {
      pthread_cond_wait(&targ->cond, &targ->mutex);
    }
    pthread_mutex_unlock(&targ->mutex);
  }
}
