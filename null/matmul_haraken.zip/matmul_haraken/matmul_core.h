// xmpcc fails when compilng a file that includes <pthread.h>.
// This is a hack to avoid the bug.
struct threads_struct;
typedef struct threads_struct threads_t;

threads_t* thread_create(int tnum, int cpuid, double* a, double* b, double* c, int n);
void thread_join(threads_t* threads);
void thread_start(threads_t* threads, int iter);
void thread_wait(threads_t* threads, int iter);
