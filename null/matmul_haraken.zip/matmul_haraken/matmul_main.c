#include "matmul_core.h"
#include "matmul_util.h"
#include <xmp.h>

/*********************************************************/
/*                                                       */
/* Please modify the following parts to change data set: */
/*   - #define SIZE                                      */
/*   - init_mat_contest()                                */
/*   - verify_mat_contest()                              */
/*                                                       */
/*********************************************************/

/********************************************/
/*                                          */
/* Modify this value to change matrix size. */
/*                                          */
/********************************************/
#define SIZE 2048

#define SQRT_PNUM 4
#define STRIPE_NUM 4

#ifdef SIZE_OVERWRITE
#undef SIZE
#define SIZE SIZE_OVERWRITE
#endif
#ifdef SQRT_PNUM_OVERWRITE
#undef SQRT_PNUM
#define SQRT_PNUM SQRT_PNUM_OVERWRITE
#endif

// Aligns matrix size to 128 byte.
#define N ((SIZE + 15) / 16 * 16)

#define PNUM (SQRT_PNUM * SQRT_PNUM)
#define TILE_N (N / SQRT_PNUM)

// For SSE, local_a, local_b and coarray_c must be aligned to 128 byte.
// Displaces alignment of local_a, local_b and coarray_c by 1024 byte to avoid 4 KB aliasing.
double coarray_a[TILE_N][TILE_N] __attribute__((__aligned__(4096)));
double coarray_b[TILE_N][TILE_N] __attribute__((__aligned__(4096)));
double coarray_c[TILE_N][TILE_N] __attribute__((__aligned__(4096)));
double local_a[SQRT_PNUM][TILE_N][TILE_N] __attribute__((__aligned__(1024)));
double local_b[SQRT_PNUM][TILE_N][TILE_N] __attribute__((__aligned__(2048)));
double node0_a[N][N] __attribute__((__aligned__(4096)));
double node0_b[N][N] __attribute__((__aligned__(4096)));
double node0_c[N][N] __attribute__((__aligned__(4096)));
int stat;

#pragma xmp coarray coarray_a, coarray_b, coarray_c : [*]

/********************************************************************/
/*                                                                  */
/* Modify this function to change initial values of matrix A and B. */
/*                                                                  */
/********************************************************************/
void init_mat_contest()
{
  int i, j;
  srand48(0);
  
  for(i = 0; i < SIZE; i++) {
    for(j = 0; j < SIZE; j++) {
      node0_a[i][j] = -1 * drand48() + 0.5;
    }
  }
  
  for(i = 0; i < SIZE; i++) {
    for(j = 0; j < SIZE; j++) {
      node0_b[i][j] = -1 * drand48() + 0.5;
    }
  }
}

/******************************************************************/
/*                                                                */
/* Modify this function to change verification code for matrix C. */
/*                                                                */
/******************************************************************/
void verify_mat_contest()
{
  int i, j;
  double sum = 0;
  for (i = 0; i < SIZE; i++) {
    for (j = 0; j < SIZE; j++) {
      sum += node0_c[i][j];
    }
  }
  outn("sum of elements of matrix C = %lf", sum);
}

void init_mat_test()
{
  int i, j;
  for (i = 0; i < SIZE; i++) {
    for (j = 0; j < SIZE; j++) {
      node0_a[i][j] = node0_b[i][j] = (2 * i + j) % 10;
    }
  }
}

void verify_mat_test()
{
  int i, j, k;
  int sum = 0;
  for (i = 0; i < SIZE; i++) {
    for (j = 0; j < SIZE; j++) {
      sum += (int)(node0_c[i][j]) * (2 * i + j) % 100;
    }
  }

  if (SIZE <= 512) {
    for (i = 0; i < SIZE; i++) {
      for (j = 0; j < SIZE; j++) {
        node0_c[i][j] = 0;
      }
    }
    for (i = 0; i < SIZE; i++) {
      for (k = 0; k < SIZE; k++) {
        for (j = 0; j < SIZE; j++) {
          node0_c[i][j] += node0_a[i][k] * node0_b[k][j];
        }
      }
    }

    int expected = 0;
    for (i = 0; i < SIZE; i++) {
      for (j = 0; j < SIZE; j++) {
        expected += (int)(node0_c[i][j]) * (2 * i + j) % 100;
      }
    }
    if (sum == expected) {
      errn("TEST PASS");
    } else {
      errn("TEST FAIL: sum=%d, expected=%d", sum, expected);
    }
  }
  errn("Done");
}

void init_mat()
{
  //init_mat_test();
  init_mat_contest();
}

void verify_mat()
{
  //verify_mat_test();
  verify_mat_contest();
}

void init_node0()
{
  int i, j;
  for (i = 0; i < N; i++) {
    for (j = 0; j < N; j++) {
      node0_a[i][j] = node0_b[i][j] = node0_c[i][j] = 0;
    }
  }
}

void init_local()
{
  int i, j;
  for (i = 0; i < TILE_N; i++) {
    for (j = 0; j < TILE_N; j++) {
      coarray_a[i][j] = coarray_b[i][j] = coarray_c[i][j] = 0;
      int phase;
      for (phase = 0; phase < SQRT_PNUM; phase++) {
        local_a[phase][i][j] = local_b[phase][i][j] = 0;
      }
    }
  }
}

int main(int argc, char** argv)
{
  if (argc != 2) {
    errn("usage: %s tnum", argv[0]);
    return -1;
  }
  int tnum = atoi(argv[1]);
  int rank = xmp_node_num() - 1;
  int rank_i = rank / SQRT_PNUM;
  int rank_j = rank % SQRT_PNUM;

  // Assumes that mpirun maps processes to nodes in a node file in a round robbin manner.
  int cpuid = 0;
  if (tnum == 2 && rank >= PNUM / 2) {
    cpuid = 2;
  }
  bind_to_cpu(cpuid);
  //errn("rank=%d pid=%d tnum=%d cpuid=%d", rank, getpid(), tnum, cpuid);

  if (rank == 0) {
    init_node0();
    init_mat();
  }
  init_local();
  threads_t* threads = thread_create(tnum, cpuid, local_a[0][0], local_b[0][0], coarray_c[0], TILE_N);
  xmp_sync_all(&stat);

  double t_begin = get_time();

  // Step 1: Distributes matrix A and B.
  int ti, tj;
  int phase;
  int stripe, stripe_offset;
  int stripe_num = TILE_N % STRIPE_NUM ? 1 : TILE_N / STRIPE_NUM;
  int stripe_height = TILE_N / stripe_num;
  double t1 = get_time();
  if (rank == 0) {
    for (stripe = 0; stripe < stripe_num; stripe++) {
      stripe_offset = stripe_height * stripe;

      for (ti = 0; ti < SQRT_PNUM; ti++) {
        for (tj = 0; tj < SQRT_PNUM; tj++) {
          int begin_i = TILE_N * ti + stripe_offset;
          int begin_j = TILE_N * tj;
          int dst_rank = ti * SQRT_PNUM + tj;
          if (dst_rank == 0) {
            int i;
            for (i = stripe_offset; i < stripe_offset + stripe_height; i++) {
              memcpy(coarray_a[i], node0_a[i], TILE_N * sizeof(double));
            }
          } else {
            coarray_a[stripe_offset:stripe_height][0:TILE_N]:[dst_rank + 1] = node0_a[begin_i:stripe_height][begin_j:TILE_N];
          }
        }
      }
      xmp_sync_all(&stat);

      for (ti = 0; ti < SQRT_PNUM; ti++) {
        for (tj = 0; tj < SQRT_PNUM; tj++) {
          int begin_i = TILE_N * ti + stripe_offset;
          int begin_j = TILE_N * tj;
          int dst_rank = ti * SQRT_PNUM + tj;
          if (dst_rank == 0) {
            int i;
            for (i = stripe_offset; i < stripe_offset + stripe_height; i++) {
              memcpy(coarray_b[i], node0_b[i], TILE_N * sizeof(double));
            }
          } else {
            coarray_b[stripe_offset:stripe_height][0:TILE_N]:[dst_rank + 1] = node0_b[begin_i:stripe_height][begin_j:TILE_N];
          }
        }
      }
      xmp_sync_all(&stat);
    }

    for (phase = 0; phase < SQRT_PNUM; phase++) {
      int i;
      for (i = 0; i < TILE_N; i++) {
        memcpy(&local_a[phase][i][0], &node0_a[i][phase * TILE_N], TILE_N * sizeof(double));
        memcpy(&local_b[phase][i][0], &node0_b[phase * TILE_N + i][0], TILE_N * sizeof(double));
      }
    }
  } else {
    for (stripe = 0; stripe < stripe_num; stripe++) {
      stripe_offset = stripe_height * stripe;
      xmp_sync_all(&stat);

      for (phase = 0; phase < SQRT_PNUM; phase++) {
        int a_src_rank = rank_i * SQRT_PNUM + (phase + rank_i) % SQRT_PNUM;
        if (a_src_rank == rank) {
          memcpy(local_a[phase][stripe_offset], coarray_a[stripe_offset], stripe_height * TILE_N * sizeof(double));
        } else {
          local_a[phase][stripe_offset:stripe_height][0:TILE_N] = coarray_a[stripe_offset:stripe_height][0:TILE_N]:[a_src_rank + 1];
        }
      }
      xmp_sync_all(&stat);

      for (phase = 0; phase < SQRT_PNUM; phase++) {
        int b_src_rank = ((phase + rank_i) % SQRT_PNUM) * SQRT_PNUM + rank_j;
        if (b_src_rank == rank) {
          memcpy(local_b[phase][stripe_offset], coarray_b[stripe_offset], stripe_height * TILE_N * sizeof(double));
        } else {
          local_b[phase][stripe_offset:stripe_height][0:TILE_N] = coarray_b[stripe_offset:stripe_height][0:TILE_N]:[b_src_rank + 1];
        }
      }
    }
  }

  double t2 = get_time();
  xmp_sync_all(&stat);
  double t3 = get_time();

  // Step 2: Calculates C = A * B.
  // thread_start() and thread_wait() were originally designed to dispatch calculations asynchronously
  // to overlap calculations with communications, but it turned out to be unhelpful due to hardware or
  // GASNET limitation in a given environment. Consequently, I decided to calculate synchronously.
  for (phase = 0; phase < SQRT_PNUM; phase++) {
    thread_start(threads, phase);
    thread_wait(threads, phase);
  }

  double t4 = get_time();
  xmp_sync_all(&stat);
  double t5 = get_time();

  // Step 3: Gathers matrix C.
  if (rank == 0) {
    for (ti = 0; ti < SQRT_PNUM; ti++) {
      for (tj = 0; tj < SQRT_PNUM; tj++) {
        int begin_i = TILE_N * ti;
        int begin_j = TILE_N * tj;
        int dst_rank = ti * SQRT_PNUM + tj;
        if (dst_rank == 0) {
          int i;
          for (i = 0; i < TILE_N; i++) {
            memcpy(node0_c[i], coarray_c[i], TILE_N * sizeof(double));
          }
        } else {
          node0_c[begin_i:TILE_N][begin_j:TILE_N] = coarray_c[0:TILE_N][0:TILE_N]:[dst_rank + 1];
        }
      }
    }
  }

  xmp_sync_all(&stat);
  double t6 = get_time();

  double t_end = get_time();  
  errn("rank=%d comm=%.2lf comm_sync=%.2lf calc=%.2lf calc_sync=%.2lf comm=%.2lf", rank, phase, t2 - t1, t3 - t2, t4 - t3, t5 - t4, t6 - t5);

  thread_join(threads);
  xmp_sync_all(&stat);
  if (rank == 0) {
    outn("matrix size = %d", SIZE);
    verify_mat();
    outn("time = %.2lf sec", SIZE, t_end - t_begin);
  }
  xmp_sync_all(&stat);
  return 0;
}
