#include "matmul_util.h"

void outn(const char *format, ...)
{
  va_list va_arg;
  
  va_start(va_arg, format);
  vfprintf(stdout, format, va_arg);
  fprintf(stdout, "\n");
  fflush(stdout);
  va_end(va_arg);
}

void errn(const char *format, ...)
{
  va_list va_arg;
  
  va_start(va_arg, format);
  vfprintf(stderr, format, va_arg);
  fprintf(stderr, "\n");
  fflush(stderr);
  va_end(va_arg);
}

double get_time()
{
  struct timeval tv;
  
  gettimeofday(&tv, NULL);
  return tv.tv_sec + tv.tv_usec * 1e-6;
}

void bind_to_cpu(int cpu)
{
  cpu_set_t cpu_mask;
  int ret;
  
  CPU_ZERO(&cpu_mask);
  CPU_SET(cpu, &cpu_mask);
  ret = sched_setaffinity(0, sizeof(cpu_set_t), &cpu_mask);
  if(ret < 0) errn("sched_setaffinity");
}

void halt(double time)
{
  struct timespec spec;
  
  spec.tv_sec = (int)time;
  spec.tv_nsec = (int)((time - (int)time) * 1e9);
  nanosleep(&spec, NULL);
}
