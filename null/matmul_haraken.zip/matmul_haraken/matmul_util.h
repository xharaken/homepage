#ifndef _GNU_SOURCE
#define _GNU_SOURCE
#endif

#include <math.h>
#include <sched.h>
#include <stdarg.h>
#include <stdint.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/time.h>
#include <time.h>
#include <unistd.h>

#define min(x, y) (x) <= (y) ? (x) : (y)

void outn(const char *format, ...);
void errn(const char *format, ...);
double get_time();
void bind_to_cpu(int cpu);
void halt(double time);
